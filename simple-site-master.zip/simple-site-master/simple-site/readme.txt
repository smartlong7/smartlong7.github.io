Hello

I made this website template to help you build a simple 
three page website that looks neat and tidy. 

It's built on the Blueprint CSS framework.

I've made a YouTube video to show brand new web designers how it works

http://www.youtube.com/user/philipgledhill

I hope you find the template useful and want to find out more about Blueprint CSS.

Best wishes 
Philip.



